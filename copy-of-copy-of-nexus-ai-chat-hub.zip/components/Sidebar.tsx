
import React from 'react';
import { ChatSession, UserProfile } from '../types';

interface SidebarProps {
  sessions: ChatSession[];
  activeId: string;
  onSelect: (id: string) => void;
  user: UserProfile;
}

export const Sidebar: React.FC<SidebarProps> = ({ sessions, activeId, onSelect, user }) => {
  return (
    <aside className="w-80 h-full border-r border-slate-800 bg-[#0f172a] flex flex-col hidden md:flex">
      <div className="p-6">
        <h1 className="text-2xl font-bold bg-gradient-to-r from-indigo-400 to-purple-400 bg-clip-text text-transparent">
          Nexus Chat
        </h1>
      </div>

      <nav className="flex-1 overflow-y-auto px-4 space-y-2">
        <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider px-2 mb-4">Bots Ativos</p>
        {sessions.map(session => (
          <button
            key={session.id}
            onClick={() => onSelect(session.id)}
            className={`w-full flex items-center gap-3 p-3 rounded-xl transition-all duration-200 group ${
              activeId === session.id 
                ? 'bg-indigo-600/10 border border-indigo-500/30 text-indigo-100' 
                : 'hover:bg-slate-800/50 text-slate-400 hover:text-slate-200'
            }`}
          >
            <div className="relative">
              <img src={session.avatar} className="w-12 h-12 rounded-full object-cover border-2 border-transparent group-hover:border-slate-700 transition-all" alt="" />
              <div className="absolute bottom-0 right-0 w-3 h-3 bg-emerald-500 border-2 border-[#0f172a] rounded-full"></div>
            </div>
            <div className="flex-1 text-left overflow-hidden">
              <div className="font-medium truncate">{session.name}</div>
              <div className="text-xs opacity-60 truncate">Ativo agora</div>
            </div>
          </button>
        ))}
      </nav>

      <div className="p-4 border-t border-slate-800 bg-[#1e293b]/30">
        <div className="flex items-center gap-3 p-2">
          <img src={user.avatar} className="w-10 h-10 rounded-full object-cover" alt="" />
          <div className="flex-1 overflow-hidden">
            <p className="text-sm font-medium text-slate-200 truncate">{user.name}</p>
            <p className="text-xs text-slate-500">Configurações</p>
          </div>
          <button className="text-slate-500 hover:text-slate-300 transition-colors">
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"/><circle cx="12" cy="12" r="3"/></svg>
          </button>
        </div>
      </div>
    </aside>
  );
};
