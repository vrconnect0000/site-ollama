
import React, { useState, useRef, useEffect } from 'react';
import { ChatSession, Message, UserProfile } from '../types';
import { ChatInput } from './ChatInput';

interface ChatWindowProps {
  session: ChatSession;
  onSendMessage: (text: string, image?: string) => void;
  currentUser: UserProfile;
}

export const ChatWindow: React.FC<ChatWindowProps> = ({ session, onSendMessage, currentUser }) => {
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [session.messages]);

  return (
    <div className="flex-1 flex flex-col min-h-0 bg-[#0f172a]">
      <div 
        ref={scrollRef}
        className="flex-1 overflow-y-auto p-6 space-y-6"
      >
        {session.messages.length === 0 && (
          <div className="h-full flex flex-col items-center justify-center text-slate-500 space-y-2 opacity-50">
            <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
            <p>Nenhuma mensagem ainda. Comece a conversa!</p>
          </div>
        )}
        
        {session.messages.map((msg) => {
          const isMe = msg.role === 'user' && msg.user_name === currentUser.name;
          const isBot = msg.role === 'model';
          
          return (
            <div 
              key={msg.id} 
              className={`flex animate-message ${isMe ? 'justify-end' : 'justify-start'}`}
            >
              <div className={`max-w-[85%] flex gap-3 ${isMe ? 'flex-row-reverse' : ''}`}>
                <div className="flex-shrink-0 mt-auto mb-1">
                  <img 
                    src={isBot ? session.avatar : (msg.user_avatar || 'https://picsum.photos/seed/anon/200')} 
                    className="w-8 h-8 rounded-full object-cover border border-slate-700 shadow-sm" 
                    alt="" 
                  />
                </div>
                <div className={`space-y-1 ${isMe ? 'items-end' : 'items-start'}`}>
                  {!isMe && (
                    <span className="text-[10px] font-bold text-slate-500 uppercase tracking-tighter ml-1">
                      {isBot ? session.name : msg.user_name || 'Anônimo'}
                    </span>
                  )}
                  <div className={`p-4 rounded-2xl ${
                    isMe 
                      ? 'bg-indigo-600 text-white rounded-tr-none shadow-lg shadow-indigo-600/20' 
                      : isBot 
                        ? 'bg-slate-800 text-slate-100 rounded-tl-none border border-slate-700'
                        : 'bg-slate-700/50 text-slate-200 rounded-tl-none border border-slate-600'
                  }`}>
                    {msg.image && (
                      <img src={msg.image} className="max-w-xs rounded-lg mb-3 border border-white/10" alt="Anexo" />
                    )}
                    <p className="whitespace-pre-wrap leading-relaxed text-sm md:text-base">
                      {msg.text}
                    </p>
                  </div>
                  <p className="text-[10px] text-slate-500 px-1 opacity-50">
                    {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </p>
                </div>
              </div>
            </div>
          );
        })}
      </div>
      
      <div className="p-4 md:p-6 bg-gradient-to-t from-[#0f172a] via-[#0f172a] to-transparent">
        <ChatInput onSend={onSendMessage} />
      </div>
    </div>
  );
};
