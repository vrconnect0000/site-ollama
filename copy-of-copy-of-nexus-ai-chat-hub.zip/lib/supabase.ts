
import { createClient } from '@supabase/supabase-js';

const supabaseUrl = "https://zkhradhpwakvtgsilsyj.supabase.co";
const supabaseAnonKey = "sb_publishable_UrUxPsPD3XBTANwwp3tZOA_-REppnf3";

export const supabase = createClient(supabaseUrl, supabaseAnonKey);
