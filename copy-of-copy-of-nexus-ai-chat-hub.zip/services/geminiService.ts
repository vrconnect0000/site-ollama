
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { Message } from "../types";

const getAI = () => new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const generateResponse = async (
  prompt: string, 
  history: Message[], 
  systemInstruction: string,
  image?: string
) => {
  const ai = getAI();
  const modelName = 'gemini-3-flash-preview';
  
  const contents: any[] = history.map(m => ({
    role: m.role === 'user' ? 'user' : 'model',
    parts: [{ text: m.text }]
  }));

  const parts: any[] = [{ text: prompt }];
  
  if (image) {
    const base64Data = image.split(',')[1];
    const mimeType = image.split(';')[0].split(':')[1];
    parts.push({
      inlineData: {
        data: base64Data,
        mimeType: mimeType
      }
    });
  }

  contents.push({ role: 'user', parts });

  const response = await ai.models.generateContent({
    model: modelName,
    contents: contents,
    config: {
      systemInstruction,
      temperature: 0.8,
    }
  });

  return response.text;
};

export const generateStreamingResponse = async function* (
  prompt: string,
  history: Message[],
  systemInstruction: string
) {
  const ai = getAI();
  const chat = ai.chats.create({
    model: 'gemini-3-flash-preview',
    config: {
      systemInstruction,
    }
  });

  // Pre-load history
  // Since chat.sendMessage only takes one message, we rely on the state-based contents if we were using generateContentStream.
  // For simplicity and compatibility with the chat object, we'll just send the current message.
  const response = await chat.sendMessageStream({ message: prompt });

  for await (const chunk of response) {
    yield (chunk as GenerateContentResponse).text;
  }
};
